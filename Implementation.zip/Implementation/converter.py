import pandas as pd, re, textwrap

raw = """The percentage of utilisation of MS site m1 at time t5 is 25.0 %
The percentage of utilisation of MS site m3 at time t5 is 10.0 %
The percentage of utilisation of MS site m1 at time t6 is 50.0 %
The percentage of utilisation of MS site m3 at time t6 is 20.0 %
The percentage of utilisation of MS site m1 at time t7 is 50.0 %
The percentage of utilisation of MS site m3 at time t7 is 30.0 %
The percentage of utilisation of MS site m1 at time t8 is 75.0 %
The percentage of utilisation of MS site m3 at time t8 is 40.0 %
The percentage of utilisation of MS site m1 at time t9 is 75.0 %
The percentage of utilisation of MS site m3 at time t9 is 40.0 %
The percentage of utilisation of MS site m1 at time t10 is 75.0 %
The percentage of utilisation of MS site m3 at time t10 is 40.0 %
The percentage of utilisation of MS site m1 at time t11 is 75.0 %
The percentage of utilisation of MS site m3 at time t11 is 50.0 %
The percentage of utilisation of MS site m1 at time t12 is 75.0 %
The percentage of utilisation of MS site m3 at time t12 is 50.0 %
The percentage of utilisation of MS site m1 at time t13 is 75.0 %
The percentage of utilisation of MS site m3 at time t13 is 40.0 %
The percentage of utilisation of MS site m1 at time t14 is 75.0 %
The percentage of utilisation of MS site m3 at time t14 is 40.0 %
The percentage of utilisation of MS site m1 at time t15 is 75.0 %
The percentage of utilisation of MS site m3 at time t15 is 40.0 %
The percentage of utilisation of MS site m1 at time t16 is 75.0 %
The percentage of utilisation of MS site m3 at time t16 is 60.0 %
The percentage of utilisation of MS site m1 at time t17 is 75.0 %
The percentage of utilisation of MS site m3 at time t17 is 60.0 %
The percentage of utilisation of MS site m1 at time t18 is 75.0 %
The percentage of utilisation of MS site m3 at time t18 is 60.0 %
The percentage of utilisation of MS site m1 at time t19 is 75.0 %
The percentage of utilisation of MS site m3 at time t19 is 60.0 %
The percentage of utilisation of MS site m1 at time t20 is 75.0 %
The percentage of utilisation of MS site m3 at time t20 is 70.0 %
The percentage of utilisation of MS site m1 at time t21 is 75.0 %
The percentage of utilisation of MS site m3 at time t21 is 70.0 %
The percentage of utilisation of MS site m1 at time t22 is 75.0 %
The percentage of utilisation of MS site m3 at time t22 is 60.0 %
The percentage of utilisation of MS site m1 at time t23 is 75.0 %
The percentage of utilisation of MS site m3 at time t23 is 60.0 %
The percentage of utilisation of MS site m1 at time t24 is 75.0 %
The percentage of utilisation of MS site m3 at time t24 is 70.0 %
The percentage of utilisation of MS site m1 at time t25 is 75.0 %
The percentage of utilisation of MS site m3 at time t25 is 70.0 %
The percentage of utilisation of MS site m1 at time t26 is 75.0 %
The percentage of utilisation of MS site m3 at time t26 is 60.0 %
The percentage of utilisation of MS site m1 at time t27 is 75.0 %
The percentage of utilisation of MS site m3 at time t27 is 70.0 %
The percentage of utilisation of MS site m1 at time t28 is 75.0 %
The percentage of utilisation of MS site m3 at time t28 is 70.0 %
The percentage of utilisation of MS site m1 at time t29 is 75.0 %
The percentage of utilisation of MS site m3 at time t29 is 70.0 %
The percentage of utilisation of MS site m1 at time t30 is 75.0 %
The percentage of utilisation of MS site m3 at time t30 is 70.0 %
The percentage of utilisation of MS site m1 at time t31 is 75.0 %
The percentage of utilisation of MS site m3 at time t31 is 60.0 %
The percentage of utilisation of MS site m1 at time t32 is 75.0 %
The percentage of utilisation of MS site m3 at time t32 is 50.0 %
The percentage of utilisation of MS site m1 at time t33 is 75.0 %
The percentage of utilisation of MS site m3 at time t33 is 50.0 %
The percentage of utilisation of MS site m1 at time t34 is 75.0 %
The percentage of utilisation of MS site m3 at time t34 is 60.0 %
The percentage of utilisation of MS site m1 at time t35 is 75.0 %
The percentage of utilisation of MS site m3 at time t35 is 60.0 %
The percentage of utilisation of MS site m1 at time t36 is 75.0 %
The percentage of utilisation of MS site m3 at time t36 is 70.0 %
The percentage of utilisation of MS site m1 at time t37 is 75.0 %
The percentage of utilisation of MS site m3 at time t37 is 60.0 %
The percentage of utilisation of MS site m1 at time t38 is 75.0 %
The percentage of utilisation of MS site m3 at time t38 is 60.0 %
The percentage of utilisation of MS site m1 at time t39 is 75.0 %
The percentage of utilisation of MS site m3 at time t39 is 60.0 %
The percentage of utilisation of MS site m1 at time t40 is 75.0 %
The percentage of utilisation of MS site m3 at time t40 is 70.0 %
The percentage of utilisation of MS site m1 at time t41 is 75.0 %
The percentage of utilisation of MS site m3 at time t41 is 70.0 %
The percentage of utilisation of MS site m1 at time t42 is 75.0 %
The percentage of utilisation of MS site m3 at time t42 is 70.0 %
The percentage of utilisation of MS site m1 at time t43 is 75.0 %
The percentage of utilisation of MS site m3 at time t43 is 60.0 %
The percentage of utilisation of MS site m1 at time t44 is 75.0 %
The percentage of utilisation of MS site m3 at time t44 is 60.0 %
The percentage of utilisation of MS site m1 at time t45 is 75.0 %
The percentage of utilisation of MS site m3 at time t45 is 60.0 %
The percentage of utilisation of MS site m1 at time t46 is 75.0 %
The percentage of utilisation of MS site m3 at time t46 is 70.0 %
The percentage of utilisation of MS site m1 at time t47 is 75.0 %
The percentage of utilisation of MS site m3 at time t47 is 70.0 %
The percentage of utilisation of MS site m1 at time t48 is 75.0 %
The percentage of utilisation of MS site m3 at time t48 is 60.0 %
The percentage of utilisation of MS site m1 at time t49 is 75.0 %
The percentage of utilisation of MS site m3 at time t49 is 70.0 %
The percentage of utilisation of MS site m1 at time t50 is 75.0 %
The percentage of utilisation of MS site m3 at time t50 is 70.0 %
The percentage of utilisation of MS site m1 at time t51 is 75.0 %
The percentage of utilisation of MS site m3 at time t51 is 70.0 %
The percentage of utilisation of MS site m1 at time t52 is 75.0 %
The percentage of utilisation of MS site m3 at time t52 is 70.0 %
The percentage of utilisation of MS site m1 at time t53 is 75.0 %
The percentage of utilisation of MS site m3 at time t53 is 70.0 %
The percentage of utilisation of MS site m1 at time t54 is 75.0 %
The percentage of utilisation of MS site m3 at time t54 is 60.0 %
The percentage of utilisation of MS site m1 at time t55 is 75.0 %
The percentage of utilisation of MS site m3 at time t55 is 50.0 %
The percentage of utilisation of MS site m1 at time t56 is 75.0 %
The percentage of utilisation of MS site m3 at time t56 is 50.0 %
The percentage of utilisation of MS site m1 at time t57 is 75.0 %
The percentage of utilisation of MS site m3 at time t57 is 50.0 %
The percentage of utilisation of MS site m1 at time t58 is 75.0 %
The percentage of utilisation of MS site m3 at time t58 is 50.0 %
The percentage of utilisation of MS site m1 at time t59 is 75.0 %
The percentage of utilisation of MS site m3 at time t59 is 50.0 %
The percentage of utilisation of MS site m1 at time t60 is 75.0 %
The percentage of utilisation of MS site m3 at time t60 is 50.0 %
The percentage of utilisation of MS site m1 at time t61 is 75.0 %
The percentage of utilisation of MS site m3 at time t61 is 70.0 %
The percentage of utilisation of MS site m1 at time t62 is 75.0 %
The percentage of utilisation of MS site m3 at time t62 is 70.0 %
The percentage of utilisation of MS site m1 at time t63 is 75.0 %
The percentage of utilisation of MS site m3 at time t63 is 60.0 %
The percentage of utilisation of MS site m1 at time t64 is 75.0 %
The percentage of utilisation of MS site m3 at time t64 is 60.0 %
The percentage of utilisation of MS site m1 at time t65 is 75.0 %
The percentage of utilisation of MS site m3 at time t65 is 60.0 %
The percentage of utilisation of MS site m1 at time t66 is 75.0 %
The percentage of utilisation of MS site m3 at time t66 is 70.0 %
The percentage of utilisation of MS site m1 at time t67 is 75.0 %
The percentage of utilisation of MS site m3 at time t67 is 70.0 %
The percentage of utilisation of MS site m1 at time t68 is 75.0 %
The percentage of utilisation of MS site m3 at time t68 is 50.0 %
The percentage of utilisation of MS site m1 at time t69 is 75.0 %
The percentage of utilisation of MS site m3 at time t69 is 60.0 %
The percentage of utilisation of MS site m1 at time t70 is 75.0 %
The percentage of utilisation of MS site m3 at time t70 is 70.0 %
The percentage of utilisation of MS site m1 at time t71 is 50.0 %
The percentage of utilisation of MS site m3 at time t71 is 70.0 %
The percentage of utilisation of MS site m1 at time t72 is 75.0 %
The percentage of utilisation of MS site m3 at time t72 is 70.0 %
The percentage of utilisation of MS site m1 at time t73 is 75.0 %
The percentage of utilisation of MS site m3 at time t73 is 70.0 %
The percentage of utilisation of MS site m1 at time t74 is 75.0 %
The percentage of utilisation of MS site m3 at time t74 is 70.0 %
The percentage of utilisation of MS site m1 at time t75 is 75.0 %
The percentage of utilisation of MS site m3 at time t75 is 70.0 %
The percentage of utilisation of MS site m1 at time t76 is 75.0 %
The percentage of utilisation of MS site m3 at time t76 is 70.0 %
The percentage of utilisation of MS site m1 at time t77 is 75.0 %
The percentage of utilisation of MS site m3 at time t77 is 50.0 %
The percentage of utilisation of MS site m1 at time t78 is 75.0 %
The percentage of utilisation of MS site m3 at time t78 is 50.0 %
The percentage of utilisation of MS site m1 at time t79 is 75.0 %
The percentage of utilisation of MS site m3 at time t79 is 60.0 %
The percentage of utilisation of MS site m1 at time t80 is 75.0 %
The percentage of utilisation of MS site m3 at time t80 is 50.0 %
The percentage of utilisation of MS site m1 at time t81 is 75.0 %
The percentage of utilisation of MS site m3 at time t81 is 60.0 %
The percentage of utilisation of MS site m1 at time t82 is 75.0 %
The percentage of utilisation of MS site m3 at time t82 is 70.0 %
The percentage of utilisation of MS site m1 at time t83 is 75.0 %
The percentage of utilisation of MS site m3 at time t83 is 70.0 %
The percentage of utilisation of MS site m1 at time t84 is 75.0 %
The percentage of utilisation of MS site m3 at time t84 is 70.0 %
The percentage of utilisation of MS site m1 at time t85 is 75.0 %
The percentage of utilisation of MS site m3 at time t85 is 70.0 %
The percentage of utilisation of MS site m1 at time t86 is 75.0 %
The percentage of utilisation of MS site m3 at time t86 is 50.0 %
The percentage of utilisation of MS site m1 at time t87 is 75.0 %
The percentage of utilisation of MS site m3 at time t87 is 60.0 %
The percentage of utilisation of MS site m1 at time t88 is 75.0 %
The percentage of utilisation of MS site m3 at time t88 is 70.0 %
The percentage of utilisation of MS site m1 at time t89 is 75.0 %
The percentage of utilisation of MS site m3 at time t89 is 70.0 %
The percentage of utilisation of MS site m1 at time t90 is 75.0 %
The percentage of utilisation of MS site m3 at time t90 is 60.0 %
The percentage of utilisation of MS site m1 at time t91 is 75.0 %
The percentage of utilisation of MS site m3 at time t91 is 70.0 %
The percentage of utilisation of MS site m1 at time t92 is 75.0 %
The percentage of utilisation of MS site m3 at time t92 is 70.0 %
The percentage of utilisation of MS site m1 at time t93 is 75.0 %
The percentage of utilisation of MS site m3 at time t93 is 70.0 %
The percentage of utilisation of MS site m1 at time t94 is 75.0 %
The percentage of utilisation of MS site m3 at time t94 is 60.0 %
The percentage of utilisation of MS site m1 at time t95 is 75.0 %
The percentage of utilisation of MS site m3 at time t95 is 60.0 %
The percentage of utilisation of MS site m1 at time t96 is 75.0 %
The percentage of utilisation of MS site m3 at time t96 is 70.0 %
The percentage of utilisation of MS site m1 at time t97 is 75.0 %
The percentage of utilisation of MS site m3 at time t97 is 70.0 %
The percentage of utilisation of MS site m1 at time t98 is 75.0 %
The percentage of utilisation of MS site m3 at time t98 is 60.0 %
The percentage of utilisation of MS site m1 at time t99 is 75.0 %
The percentage of utilisation of MS site m3 at time t99 is 60.0 %
The percentage of utilisation of MS site m1 at time t100 is 50.0 %
The percentage of utilisation of MS site m3 at time t100 is 60.0 %
The percentage of utilisation of MS site m1 at time t101 is 50.0 %
The percentage of utilisation of MS site m3 at time t101 is 60.0 %
The percentage of utilisation of MS site m1 at time t102 is 50.0 %
The percentage of utilisation of MS site m3 at time t102 is 30.0 %
The percentage of utilisation of MS site m1 at time t103 is 25.0 %
The percentage of utilisation of MS site m3 at time t103 is 10.0 %"""

pattern = r"MS site (m\d+) at time t(\d+)\s+is\s+([0-9.]+)\s*%"
data = {}
sites = set()

for line in raw.splitlines():
    m = re.search(pattern, line)
    if not m:
        continue
    site, t, val = m.group(1), int(m.group(2)), float(m.group(3))
    sites.add(site)
    data.setdefault(t, {})[site] = val

sites = sorted(sites, key=lambda s: int(s[1:]))
tmin, tmax = min(data), max(data)
times = list(range(tmin, tmax + 1))

df = pd.DataFrame({"time": [f"t{t}" for t in times]})
for s in sites:
    df[s] = [data.get(t, {}).get(s, 0.0) for t in times]

out_path = "ms_utilisation_m1_m3_t5_t103_v2.csv"
df.to_csv(out_path, index=False, float_format="%.2f")

df.head(8), df.tail(8), out_path





